<?php 
    require_once( dirname(dirname(__FILE__)) . '/wp-load.php' );
    
    $contest_id = intval( filter_input( INPUT_POST, 'contest' ) );

    $contest_data_sql = "
            SELECT T1.post_title, T2.meta_value AS start_date, T3.meta_value AS end_date FROM " . $wpdb->prefix . "posts AS T1
                LEFT JOIN " . $wpdb->prefix . "postmeta AS T2 ON T1.ID = T2.post_id
                    LEFT JOIN " . $wpdb->prefix . "postmeta AS T3 ON T1.ID = T3.post_id
                        WHERE T1.ID = {$contest_id} 
                            AND T2.meta_key = 'start_date'
                                AND T3.meta_key = 'end_date'
                                LIMIT 1
            ";
    $contest_data = $wpdb->get_results( $contest_data_sql );

    $contest_name = $contest_data[0]->post_title;
    
    $start_date = explode('-', $contest_data[0]->start_date);
    $start_date_year = $start_date[0];
    $start_date_month = $start_date[1];
    $start_date_day = $start_date[2];
    $unix_start_date = strtotime($contest_data[0]->start_date);

    $end_date = explode('-', $contest_data[0]->end_date);
    $end_date_year = $end_date[0];
    $end_date_month = $end_date[1];
    $end_date_day = $end_date[2];
    $unix_end_date = strtotime($contest_data[0]->end_date);

    //echo '<pre>'; print_r($start_date[0]); echo '</pre>';
    //echo '<pre>'; print_r($start_date[1]); echo '</pre>';
    //echo '<pre>'; print_r($start_date[2]); echo '</pre>';

//    $scorul_pe_o_perioada_sql = "
//            SELECT id_wp_player, SUM(score) as all_score 
//                FROM " . $wpdb->prefix . "players_score 
//                WHERE 
//                    (day >= {$start_date_day} && day <= {$end_date_day}) 
//                    AND (month >= {$start_date_month} && month <= $end_date_month) 
//                    AND (year >= {$start_date_year} && year <= {$end_date_year}) 
//                    GROUP BY id_wp_player
//            ";
    $scorul_pe_o_perioada_sql = "
            SELECT id_wp_player, SUM(score) as all_score 
                FROM " . $wpdb->prefix . "players_score 
                WHERE 
                    unixtime >= {$unix_start_date} 
                        AND unixtime <= {$unix_end_date}
                    GROUP BY id_wp_player
            ";
                        
//$file = 'text.txt';
//// Write the contents back to the file
//file_put_contents($file, $scorul_pe_o_perioada_sql);

    $scorul_pe_o_perioada = $wpdb->get_results( $scorul_pe_o_perioada_sql );
    $players_score_array = array();
    foreach($scorul_pe_o_perioada as $v) {
        $players_score_array[$v->id_wp_player] = round($v->all_score, 2);
    }

//    echo '<pre>'; print_r($scorul_pe_o_perioada); echo '</pre>'; 


    $toti_participantii_pentru_un_contest_sql = "
                SELECT * FROM " . $wpdb->prefix . "participants WHERE id_contest= {$contest_id};
            ";
    $toti_participantii_pentru_un_contest = $wpdb->get_results( $toti_participantii_pentru_un_contest_sql );

    //echo '<pre>'; print_r($toti_participantii_pentru_un_contest); echo '</pre>'; 

    $participantii_array = array();

    foreach($toti_participantii_pentru_un_contest as $v) {
        $ar = array();
        $ar['id_user'] = $v->id_user;
        $ar['id_player_qbf'] = $v->id_player_qbf;
        $ar['id_player_qbs'] = $v->id_player_qbs;
        $ar['id_player_rbf'] = $v->id_player_rbf;
        $ar['id_player_rbs'] = $v->id_player_rbs;
        $ar['id_player_wrf'] = $v->id_player_wrf;
        $ar['id_player_wrs'] = $v->id_player_wrs;
        $participantii_array[$v->id_participants] = $ar;
    }

//    echo '<pre>'; print_r($participantii_array); echo '</pre>'; 

    $participanti_score_array = array();

    foreach($toti_participantii_pentru_un_contest as $v) {
        $score = 0;
        $score = $players_score_array[$v->id_player_qbf] + 
                    $players_score_array[$v->id_player_qbs] +
                    $players_score_array[$v->id_player_rbf] +
                    $players_score_array[$v->id_player_rbs] +
                    $players_score_array[$v->id_player_wrf] +
                    $players_score_array[$v->id_player_wrs];

        $participanti_score_array[$v->id_participants] = $score;
    }
    
    asort($participanti_score_array);

//    echo '<pre>'; print_r($participanti_score_array); echo '</pre>'; 

    $all_users_sql = "SELECT * FROM " . $wpdb->prefix . "users";
    $all_users = $wpdb->get_results( $all_users_sql );
    $array_users = array();
    foreach($all_users as $au) {
        $array_users[$au->ID] = $au->user_nicename;
    }

//    echo '<pre>'; print_r($array_users); echo '</pre>'; 

    $all_players_sql = "
            SELECT T1.ID, T1.post_title AS player_name, T3.post_title AS position FROM " . $wpdb->prefix . "posts AS T1
                LEFT JOIN " . $wpdb->prefix . "postmeta AS T2 ON T1.ID = T2.post_id
                    LEFT JOIN  " . $wpdb->prefix . "posts AS T3 ON T2.meta_value = T3.ID
                WHERE T1.post_type = 'players'
                    AND T2.meta_key = 'position' ";

    $all_players = $wpdb->get_results( $all_players_sql );

    //echo '<pre>'; print_r($all_players); echo '</pre>'; 

    $array_players = array();
    foreach($all_players as $ap) {
        $arr = array();
        $arr['player_name'] = $ap->player_name;
        $arr['position'] = $ap->position;
        $array_players[$ap->ID] = $arr;
    }

//    echo '<pre>'; print_r($array_players); echo '</pre>'; 

    
    $html="

        <thead>
            <tr>
                <th>Rank</th>
                <th>Name</th>
                <th>Contest</th>
                <th>Quarterbacks</th>
                <th>Running Backs</th>
                <th>Wide Receivers</th>
                <th>Points</th>
            </tr>
        </thead>
        <tbody>";
    $i = 1;
    foreach($participanti_score_array as $k=>$v) {
        $user_name = $array_users[$participantii_array[$k]['id_user']];
        
        $id_player_qbf = $participantii_array[$k]['id_player_qbf'];
        $id_player_qbs = $participantii_array[$k]['id_player_qbs'];
        $id_player_rbf = $participantii_array[$k]['id_player_rbf'];
        $id_player_rbs = $participantii_array[$k]['id_player_rbs'];
        $id_player_wrf = $participantii_array[$k]['id_player_wrf'];
        $id_player_wrs = $participantii_array[$k]['id_player_wrs'];
        
        $qbf_score = $players_score_array[$id_player_qbf] == 0 ? 0 : $players_score_array[$id_player_qbf];
        $qbs_score = $players_score_array[$id_player_qbs] == 0 ? 0 : $players_score_array[$id_player_qbs];
        $rbf_score = $players_score_array[$id_player_rbf] == 0 ? 0 : $players_score_array[$id_player_rbf];
        $rbs_score = $players_score_array[$id_player_rbs] == 0 ? 0 : $players_score_array[$id_player_rbs];
        $wrf_score = $players_score_array[$id_player_wrf] == 0 ? 0 : $players_score_array[$id_player_wrf];
        $wrs_score = $players_score_array[$id_player_wrs] == 0 ? 0 : $players_score_array[$id_player_wrs];
        
        $html .="                
                <tr>
                    <td>{$i}</td>
                    <td style=\"text-align: left;\">{$user_name}</td>
                    <td>{$contest_name}</td>
                    <td>
                        {$array_players[$id_player_qbf]['player_name']}<span style=\"color:orange;\">({$qbf_score})</span><br />
                        {$array_players[$id_player_qbs]['player_name']}<span style=\"color:orange;\">({$qbs_score})</span><br />
                    </td>
                    <td>
                        {$array_players[$id_player_rbf]['player_name']}<span style=\"color:orange;\">({$rbf_score})</span><br />
                        {$array_players[$id_player_rbs]['player_name']}<span style=\"color:orange;\">({$rbs_score})</span><br />
                    </td>
                    <td>
                        {$array_players[$id_player_wrf]['player_name']}<span style=\"color:orange;\">({$wrf_score})</span><br />
                        {$array_players[$id_player_wrs]['player_name']}<span style=\"color:orange;\">({$wrs_score})</span><br />
                    </td>
                    <td>
                        <span style=\"color:orange;font-weight: bold;\">{$v}</span></ br>
                    </td>
                </tr>
                ";
        $i++;
    }
    $html .="
        </tbody>
        <tfoot>
            <tr>
                <th>Rank</th>
                <th>Name</th>
                <th>Contest</th>
                <th>Quarterbacks</th>
                <th>Running Backs</th>
                <th>Wide Receivers</th>
                <th>Points</th>
            </tr>
        </tfoot>

        ";
                
    $response = array('html'=>$html, 'start_date'=>$contest_data[0]->start_date, 'end_date'=>$contest_data[0]->end_date);
    echo json_encode($response); 
?>